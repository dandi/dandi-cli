# Largely a helper to quickly trigger fixtures to smoke test them
# and possibly go through their internal asserts

from pathlib import Path


def test_organized_nwb_dir(organized_nwb_dir: Path) -> None:
    pass  # Just a smoke test to trigger fixture's asserts


def test_organized_nwb_dir2(organized_nwb_dir2: Path) -> None:
    pass  # Just a smoke test to trigger fixture's asserts
